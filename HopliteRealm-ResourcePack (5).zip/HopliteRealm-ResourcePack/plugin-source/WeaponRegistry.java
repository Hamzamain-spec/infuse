package com.hoplite.weapons;

import com.hoplite.HoplitePlugin;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Registry for all legendary weapons. Handles event dispatch and item lookups.
 */
public class WeaponRegistry {

    private final List<LegendaryWeapon>        weapons   = new ArrayList<>();
    private final Map<String, LegendaryWeapon> byKey     = new HashMap<>();

    public WeaponRegistry(HoplitePlugin plugin) {
        register(new ZeusSword(plugin));
        register(new InfernoAxe(plugin));
        register(new ThunderHammer(plugin));
        register(new ShadowDagger(plugin));
        register(new IceBlade(plugin));
    }

    private void register(LegendaryWeapon weapon) {
        weapons.add(weapon);
        byKey.put(weapon.getKey(), weapon);
    }

    /** Returns the weapon that matches the given ItemStack, or null. */
    public LegendaryWeapon getWeapon(ItemStack item) {
        if (item == null) return null;
        for (LegendaryWeapon w : weapons) {
            if (w.matches(item)) return w;
        }
        return null;
    }

    /** Returns a weapon by its string key (e.g. "zeus-sword"), or null. */
    public LegendaryWeapon getWeapon(String key) {
        return byKey.get(key);
    }

    public boolean isLegendaryWeapon(ItemStack item) {
        return getWeapon(item) != null;
    }

    public void handleAttack(Player attacker, Player victim, ItemStack weapon) {
        LegendaryWeapon lw = getWeapon(weapon);
        if (lw != null) {
            lw.onAttack(attacker, victim);
            var stats = HoplitePlugin.getInstance().getDatabaseManager().getCachedStats(attacker.getUniqueId());
            if (stats != null) stats.addLegendaryUse();
        }
    }

    public void handleRightClick(Player player, ItemStack weapon) {
        LegendaryWeapon lw = getWeapon(weapon);
        if (lw != null) lw.onRightClick(player);
    }

    public List<LegendaryWeapon> getAllWeapons() { return weapons; }
}
