package com.hoplite.weapons;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Base class for all legendary weapons.
 * Handles ability triggering, cooldown tracking, and item identity.
 */
public abstract class LegendaryWeapon {

    protected final String key;
    protected final String displayName;
    protected final int cooldownSeconds;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    protected LegendaryWeapon(String key, String displayName, int cooldownSeconds) {
        this.key = key;
        this.displayName = displayName;
        this.cooldownSeconds = cooldownSeconds;
    }

    /**
     * Called when the player attacks another player with this weapon.
     */
    public abstract void onAttack(Player attacker, Player victim);

    /**
     * Called when the player right-clicks with this weapon.
     */
    public abstract void onRightClick(Player player);

    /**
     * Returns the ItemStack representing this weapon.
     */
    public abstract ItemStack createItem();

    /**
     * Returns true if this ItemStack is this legendary weapon.
     */
    public abstract boolean matches(ItemStack item);

    public boolean isOnCooldown(Player player) {
        long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        return (System.currentTimeMillis() - last) < (cooldownSeconds * 1000L);
    }

    public long getRemainingCooldown(Player player) {
        long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        long elapsed = System.currentTimeMillis() - last;
        long remaining = (cooldownSeconds * 1000L) - elapsed;
        return Math.max(0, remaining / 1000);
    }

    public void triggerCooldown(Player player) {
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public String getKey() { return key; }
    public String getDisplayName() { return displayName; }
    public int getCooldownSeconds() { return cooldownSeconds; }
}
