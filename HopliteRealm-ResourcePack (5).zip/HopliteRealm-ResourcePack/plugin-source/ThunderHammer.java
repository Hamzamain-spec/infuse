package com.hoplite.weapons;

import com.hoplite.HoplitePlugin;
import com.hoplite.utils.ItemBuilder;
import com.hoplite.utils.MessageUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

/**
 * Thunder Hammer — massive knockback on hit; right-click slams all nearby enemies.
 */
public class ThunderHammer extends LegendaryWeapon {

    private final HoplitePlugin plugin;
    private static final String IDENTIFIER = "HOPLITE_THUNDER_HAMMER";

    public ThunderHammer(HoplitePlugin plugin) {
        super("thunder-hammer", "&e&lThunder Hammer",
            plugin.getConfigManager().getWeaponCooldown("thunder-hammer"));
        this.plugin = plugin;
    }

    @Override
    public void onAttack(Player attacker, Player victim) {
        if (isOnCooldown(attacker)) {
            attacker.sendActionBar(net.kyori.adventure.text.Component.text(
                MessageUtils.colorize("&cThunder Hammer on cooldown! &7(" + getRemainingCooldown(attacker) + "s)")));
            return;
        }
        triggerCooldown(attacker);
        double multiplier = plugin.getConfig().getDouble("weapons.thunder-hammer.knockback-multiplier", 3.0);
        Vector dir = victim.getLocation().toVector().subtract(attacker.getLocation().toVector()).normalize();
        dir.setY(0.5).multiply(multiplier);
        victim.setVelocity(dir);
        victim.getWorld().spawnParticle(Particle.CLOUD, victim.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.1);
        victim.playSound(victim.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1f, 0.5f);
        attacker.sendActionBar(net.kyori.adventure.text.Component.text(
            MessageUtils.colorize("&e⚡ Thunder Hammer activated!")));
    }

    @Override
    public void onRightClick(Player player) {
        if (isOnCooldown(player)) return;
        triggerCooldown(player);
        player.getWorld().spawnParticle(Particle.EXPLOSION, player.getLocation(), 3, 1, 1, 1, 0);
        player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.5f);
        for (org.bukkit.entity.Entity e : player.getNearbyEntities(6, 3, 6)) {
            if (e instanceof Player nearby && !nearby.equals(player)) {
                Vector dir = nearby.getLocation().toVector().subtract(player.getLocation().toVector()).normalize();
                dir.setY(1.0).multiply(2.5);
                nearby.setVelocity(dir);
            }
        }
    }

    @Override
    public ItemStack createItem() {
        return new ItemBuilder(Material.IRON_AXE)
            .setName(displayName)
            .setLore(
                "&7Forged by Hephaestus himself,",
                "&7this hammer shakes the earth.",
                "",
                "&e⚡ Passive: Massive knockback on hit",
                "&e⚡ Active: Slam all nearby foes (right-click)",
                "",
                "&8Cooldown: &7" + cooldownSeconds + " seconds",
                "&8" + IDENTIFIER
            )
            .addEnchant(Enchantment.SHARPNESS, 5)
            .addEnchant(Enchantment.KNOCKBACK, 3)
            .addEnchant(Enchantment.UNBREAKING, 3)
            .setUnbreakable(true)
            .setGlowing(true)
            .setCustomModelData(2003)
            .build();
    }

    @Override
    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.IRON_AXE) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) return false;
        return meta.getLore().stream().anyMatch(l -> l.contains(IDENTIFIER));
    }
}
