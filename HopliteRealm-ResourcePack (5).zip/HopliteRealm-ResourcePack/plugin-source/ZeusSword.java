package com.hoplite.weapons;

import com.hoplite.HoplitePlugin;
import com.hoplite.utils.ItemBuilder;
import com.hoplite.utils.MessageUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Zeus Sword — calls down lightning bolts on hit (configurable count).
 * Right-click: strikes lightning at target location.
 */
public class ZeusSword extends LegendaryWeapon {

    private final HoplitePlugin plugin;
    private static final String IDENTIFIER = "HOPLITE_ZEUS_SWORD";

    public ZeusSword(HoplitePlugin plugin) {
        super("zeus-sword", "&b&lZeus Sword",
            plugin.getConfigManager().getWeaponCooldown("zeus-sword"));
        this.plugin = plugin;
    }

    @Override
    public void onAttack(Player attacker, Player victim) {
        if (isOnCooldown(attacker)) {
            attacker.sendActionBar(net.kyori.adventure.text.Component.text(
                MessageUtils.colorize("&cZeus Sword on cooldown! &7(" + getRemainingCooldown(attacker) + "s)")));
            return;
        }
        triggerCooldown(attacker);
        int strikes = plugin.getConfig().getInt("weapons.zeus-sword.lightning-strikes", 3);
        for (int i = 0; i < strikes; i++) {
            double offsetX = (Math.random() - 0.5) * 4;
            double offsetZ = (Math.random() - 0.5) * 4;
            Location loc = victim.getLocation().add(offsetX, 0, offsetZ);
            victim.getWorld().strikeLightning(loc);
        }
        victim.playSound(victim.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1f);
        attacker.sendActionBar(net.kyori.adventure.text.Component.text(
            MessageUtils.colorize("&b⚡ Zeus Sword activated!")));
        plugin.getDatabaseManager().getCachedStats(attacker.getUniqueId());
    }

    @Override
    public void onRightClick(Player player) {
        if (isOnCooldown(player)) {
            player.sendActionBar(net.kyori.adventure.text.Component.text(
                MessageUtils.colorize("&cCooldown: &7" + getRemainingCooldown(player) + "s")));
            return;
        }
        triggerCooldown(player);
        Location target = player.getTargetBlock(null, 30).getLocation();
        player.getWorld().strikeLightning(target);
        player.playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1f);
    }

    @Override
    public ItemStack createItem() {
        return new ItemBuilder(Material.DIAMOND_SWORD)
            .setName(displayName)
            .setLore(
                "&7Calls down the wrath of Zeus",
                "&7on your enemies.",
                "",
                "&e⚡ Passive: Lightning on hit",
                "&e⚡ Active: Strike at cursor (right-click)",
                "",
                "&8Cooldown: &7" + cooldownSeconds + " seconds",
                "&8" + IDENTIFIER
            )
            .addEnchant(Enchantment.SHARPNESS, 4)
            .addEnchant(Enchantment.UNBREAKING, 3)
            .setUnbreakable(true)
            .setGlowing(true)
            .setCustomModelData(2001)
            .build();
    }

    @Override
    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_SWORD) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) return false;
        return meta.getLore().stream().anyMatch(l -> l.contains(IDENTIFIER));
    }
}
