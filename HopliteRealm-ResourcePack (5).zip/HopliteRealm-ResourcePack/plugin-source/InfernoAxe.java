package com.hoplite.weapons;

import com.hoplite.HoplitePlugin;
import com.hoplite.utils.ItemBuilder;
import com.hoplite.utils.MessageUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Inferno Axe — sets enemies on fire and applies wither on hit.
 */
public class InfernoAxe extends LegendaryWeapon {

    private final HoplitePlugin plugin;
    private static final String IDENTIFIER = "HOPLITE_INFERNO_AXE";

    public InfernoAxe(HoplitePlugin plugin) {
        super("inferno-axe", "&c&lInferno Axe",
            plugin.getConfigManager().getWeaponCooldown("inferno-axe"));
        this.plugin = plugin;
    }

    @Override
    public void onAttack(Player attacker, Player victim) {
        if (isOnCooldown(attacker)) {
            attacker.sendActionBar(net.kyori.adventure.text.Component.text(
                MessageUtils.colorize("&cInferno Axe on cooldown! &7(" + getRemainingCooldown(attacker) + "s)")));
            return;
        }
        triggerCooldown(attacker);
        int fireTicks = plugin.getConfig().getInt("weapons.inferno-axe.fire-duration-seconds", 5) * 20;
        victim.setFireTicks(fireTicks);
        victim.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0, false, true, true));
        victim.getWorld().spawnParticle(Particle.FLAME, victim.getLocation().add(0, 1, 0), 20, 0.3f, 0.5f, 0.3f, 0.05);
        victim.playSound(victim.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
        attacker.sendActionBar(net.kyori.adventure.text.Component.text(
            MessageUtils.colorize("&c🔥 Inferno Axe activated!")));
    }

    @Override
    public void onRightClick(Player player) {
        if (isOnCooldown(player)) return;
        triggerCooldown(player);
        // AOE fire burst around the player
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.FLAME, loc, 60, 3, 1, 3, 0.1);
        for (org.bukkit.entity.Entity e : player.getNearbyEntities(5, 3, 5)) {
            if (e instanceof Player nearby && !nearby.equals(player)) {
                nearby.setFireTicks(60);
                nearby.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 40, 0));
            }
        }
        player.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.5f, 0.5f);
    }

    @Override
    public ItemStack createItem() {
        return new ItemBuilder(Material.DIAMOND_AXE)
            .setName(displayName)
            .setLore(
                "&7Forged in the fires of the underworld,",
                "&7this axe burns all it touches.",
                "",
                "&c🔥 Passive: Sets enemy ablaze on hit",
                "&c🔥 Active: Fire burst (right-click)",
                "",
                "&8Cooldown: &7" + cooldownSeconds + " seconds",
                "&8" + IDENTIFIER
            )
            .addEnchant(Enchantment.SHARPNESS, 3)
            .addEnchant(Enchantment.FIRE_ASPECT, 2)
            .addEnchant(Enchantment.UNBREAKING, 3)
            .setUnbreakable(true)
            .setGlowing(true)
            .setCustomModelData(2002)
            .build();
    }

    @Override
    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.DIAMOND_AXE) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) return false;
        return meta.getLore().stream().anyMatch(l -> l.contains(IDENTIFIER));
    }
}
