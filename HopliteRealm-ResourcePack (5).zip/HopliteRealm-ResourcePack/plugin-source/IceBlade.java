package com.hoplite.weapons;

import com.hoplite.HoplitePlugin;
import com.hoplite.utils.ItemBuilder;
import com.hoplite.utils.MessageUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Ice Blade — slows and blinds enemies on hit; right-click freezes in place briefly.
 */
public class IceBlade extends LegendaryWeapon {

    private final HoplitePlugin plugin;
    private static final String IDENTIFIER = "HOPLITE_ICE_BLADE";

    public IceBlade(HoplitePlugin plugin) {
        super("ice-blade", "&3&lIce Blade",
            plugin.getConfigManager().getWeaponCooldown("ice-blade"));
        this.plugin = plugin;
    }

    @Override
    public void onAttack(Player attacker, Player victim) {
        if (isOnCooldown(attacker)) {
            attacker.sendActionBar(net.kyori.adventure.text.Component.text(
                MessageUtils.colorize("&cIce Blade on cooldown! &7(" + getRemainingCooldown(attacker) + "s)")));
            return;
        }
        triggerCooldown(attacker);
        int slowTicks = plugin.getConfig().getInt("weapons.ice-blade.slow-duration-seconds", 4) * 20;
        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slowTicks, 2, false, true, true));
        victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, slowTicks / 2, 0, false, true, true));
        victim.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, victim.getLocation().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.01);
        victim.playSound(victim.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1.5f);
        attacker.sendActionBar(net.kyori.adventure.text.Component.text(
            MessageUtils.colorize("&3❄ Ice Blade activated!")));
    }

    @Override
    public void onRightClick(Player player) {
        if (isOnCooldown(player)) return;
        triggerCooldown(player);
        for (org.bukkit.entity.Entity e : player.getNearbyEntities(5, 3, 5)) {
            if (e instanceof Player nearby && !nearby.equals(player)) {
                nearby.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 5, false, true, true));
                nearby.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0, false, true, true));
                nearby.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, nearby.getLocation(), 20, 0.5, 1, 0.5, 0.02);
            }
        }
        player.getWorld().spawnParticle(Particle.ITEM_SNOWBALL, player.getLocation(), 50, 3, 1, 3, 0.02);
        player.playSound(player.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.5f);
    }

    @Override
    public ItemStack createItem() {
        return new ItemBuilder(Material.STONE_SWORD)
            .setName(displayName)
            .setLore(
                "&7Carved from a glacier that",
                "&7never sees the sun.",
                "",
                "&3❄ Passive: Slow + Blindness on hit",
                "&3❄ Active: Freeze nearby foes (right-click)",
                "",
                "&8Cooldown: &7" + cooldownSeconds + " seconds",
                "&8" + IDENTIFIER
            )
            .addEnchant(Enchantment.SHARPNESS, 3)
            .addEnchant(Enchantment.UNBREAKING, 3)
            .setUnbreakable(true)
            .setGlowing(true)
            .setCustomModelData(2005)
            .build();
    }

    @Override
    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.STONE_SWORD) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) return false;
        return meta.getLore().stream().anyMatch(l -> l.contains(IDENTIFIER));
    }
}
