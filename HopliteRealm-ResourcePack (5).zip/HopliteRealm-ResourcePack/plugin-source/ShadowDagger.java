package com.hoplite.weapons;

import com.hoplite.HoplitePlugin;
import com.hoplite.utils.ItemBuilder;
import com.hoplite.utils.MessageUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Shadow Dagger — grants invisibility to attacker on hit; right-click vanish dash.
 */
public class ShadowDagger extends LegendaryWeapon {

    private final HoplitePlugin plugin;
    private static final String IDENTIFIER = "HOPLITE_SHADOW_DAGGER";

    public ShadowDagger(HoplitePlugin plugin) {
        super("shadow-dagger", "&5&lShadow Dagger",
            plugin.getConfigManager().getWeaponCooldown("shadow-dagger"));
        this.plugin = plugin;
    }

    @Override
    public void onAttack(Player attacker, Player victim) {
        if (isOnCooldown(attacker)) {
            attacker.sendActionBar(net.kyori.adventure.text.Component.text(
                MessageUtils.colorize("&cShadow Dagger on cooldown! &7(" + getRemainingCooldown(attacker) + "s)")));
            return;
        }
        triggerCooldown(attacker);
        int ticks = plugin.getConfig().getInt("weapons.shadow-dagger.invisibility-duration-seconds", 3) * 20;
        attacker.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, ticks, 0, false, false, false));
        attacker.getWorld().spawnParticle(Particle.SMOKE, attacker.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.05);
        attacker.playSound(attacker.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5f, 1.5f);
        attacker.sendActionBar(net.kyori.adventure.text.Component.text(
            MessageUtils.colorize("&5👤 Shadow Dagger activated!")));
    }

    @Override
    public void onRightClick(Player player) {
        if (isOnCooldown(player)) return;
        triggerCooldown(player);
        // Vanish dash in facing direction
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 60, 0, false, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 2, false, false, false));
        player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation(), 30, 0.3, 0.5, 0.3, 0.05);
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5f, 2f);
    }

    @Override
    public ItemStack createItem() {
        return new ItemBuilder(Material.GOLDEN_SWORD)
            .setName(displayName)
            .setLore(
                "&7A blade forged in the void,",
                "&7silence follows every strike.",
                "",
                "&5👤 Passive: Invisibility on hit",
                "&5👤 Active: Vanish dash (right-click)",
                "",
                "&8Cooldown: &7" + cooldownSeconds + " seconds",
                "&8" + IDENTIFIER
            )
            .addEnchant(Enchantment.SHARPNESS, 3)
            .addEnchant(Enchantment.LOOTING, 2)
            .addEnchant(Enchantment.UNBREAKING, 3)
            .setUnbreakable(true)
            .setGlowing(true)
            .setCustomModelData(2004)
            .build();
    }

    @Override
    public boolean matches(ItemStack item) {
        if (item == null || item.getType() != Material.GOLDEN_SWORD) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore()) return false;
        return meta.getLore().stream().anyMatch(l -> l.contains(IDENTIFIER));
    }
}
