ShulkerSMP Power Shell resource pack

This pack is required for the eight Power Shells to render with different
colors. The server item remains the real minecraft:shulker_shell.

Upload the ZIP containing this folder's contents to an HTTPS direct-download
URL. Set that URL and the ZIP's SHA-1 hash in the plugin resource-pack
configuration. Do not upload this outer source folder as an extra nesting
level: pack.mcmeta must be at the ZIP root.