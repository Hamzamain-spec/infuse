=====================================================
  HOPLITE REALM - DARK FANTASY PvP RESOURCE PACK
  Minecraft Java Edition | Pack Format 18 (1.20.x)
  Paired with: HoplitePlugin legendary weapon system
=====================================================

INSTALLATION — RESOURCE PACK
------------------------------
1. Place the "HopliteRealm-ResourcePack" folder into:
   .minecraft/resourcepacks/
2. Launch Minecraft → Options → Resource Packs
3. Enable "Hoplite Realm" and click Done

INSTALLATION — PLUGIN
------------------------------
Place compiled HoplitePlugin.jar into your server's /plugins/ folder.
The weapons are registered automatically via WeaponRegistry on startup.

=====================================================
  LEGENDARY WEAPONS — FULL REFERENCE
=====================================================

┌─────────────────────────────────────────────────────────────────┐
│  ZEUS SWORD                                                     │
│  Class: ZeusSword.java  |  Key: zeus-sword                     │
│  Base Material: DIAMOND_SWORD  |  CustomModelData: 2001        │
│  Texture: textures/item/custom/zeus_sword.png                  │
│                                                                 │
│  Enchantments: Sharpness IV, Unbreaking III                    │
│  Passive: Strikes lightning bolts on hit (configurable count)  │
│  Active:  Right-click → strikes lightning at cursor target     │
│                                                                 │
│  Lore:                                                          │
│    "Calls down the wrath of Zeus on your enemies."             │
│    ⚡ Passive: Lightning on hit                                 │
│    ⚡ Active: Strike at cursor (right-click)                    │
│                                                                 │
│  Config key: weapons.zeus-sword.lightning-strikes (default 3)  │
│  Identifier: HOPLITE_ZEUS_SWORD                                │
│                                                                 │
│  /give command:                                                 │
│  /give @p diamond_sword{CustomModelData:2001,                  │
│    display:{Name:'{"text":"Zeus Sword","color":"aqua",         │
│    "bold":true}'}}                                             │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  INFERNO AXE                                                    │
│  Class: InfernoAxe.java  |  Key: inferno-axe                  │
│  Base Material: DIAMOND_AXE  |  CustomModelData: 2002         │
│  Texture: textures/item/custom/inferno_axe.png                 │
│                                                                 │
│  Enchantments: Sharpness III, Fire Aspect II, Unbreaking III   │
│  Passive: Sets enemy on fire + Wither effect on hit            │
│  Active:  Right-click → AOE fire burst around player          │
│                                                                 │
│  Lore:                                                          │
│    "Forged in the fires of the underworld,                     │
│     this axe burns all it touches."                            │
│    🔥 Passive: Sets enemy ablaze on hit                         │
│    🔥 Active: Fire burst (right-click)                          │
│                                                                 │
│  Config key: weapons.inferno-axe.fire-duration-seconds (def 5) │
│  Identifier: HOPLITE_INFERNO_AXE                               │
│                                                                 │
│  /give command:                                                 │
│  /give @p diamond_axe{CustomModelData:2002,                    │
│    display:{Name:'{"text":"Inferno Axe","color":"red",         │
│    "bold":true}'}}                                             │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  THUNDER HAMMER                                                 │
│  Class: ThunderHammer.java  |  Key: thunder-hammer            │
│  Base Material: IRON_AXE  |  CustomModelData: 2003            │
│  Texture: textures/item/custom/thunder_hammer.png              │
│                                                                 │
│  Enchantments: Sharpness V, Knockback III, Unbreaking III      │
│  Passive: Massive knockback on hit (configurable multiplier)   │
│  Active:  Right-click → slams all nearby enemies airborne      │
│                                                                 │
│  Lore:                                                          │
│    "Forged by Hephaestus himself,                              │
│     this hammer shakes the earth."                             │
│    ⚡ Passive: Massive knockback on hit                         │
│    ⚡ Active: Slam all nearby foes (right-click)                │
│                                                                 │
│  Config: weapons.thunder-hammer.knockback-multiplier (def 3.0) │
│  Identifier: HOPLITE_THUNDER_HAMMER                            │
│                                                                 │
│  /give command:                                                 │
│  /give @p iron_axe{CustomModelData:2003,                       │
│    display:{Name:'{"text":"Thunder Hammer","color":"yellow",   │
│    "bold":true}'}}                                             │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  SHADOW DAGGER                                                  │
│  Class: ShadowDagger.java  |  Key: shadow-dagger              │
│  Base Material: GOLDEN_SWORD  |  CustomModelData: 2004        │
│  Texture: textures/item/custom/shadow_dagger.png               │
│                                                                 │
│  Enchantments: Sharpness III, Looting II, Unbreaking III       │
│  Passive: Grants attacker Invisibility on hit                  │
│  Active:  Right-click → vanish dash (Invisibility + Speed III) │
│                                                                 │
│  Lore:                                                          │
│    "A blade forged in the void,                                │
│     silence follows every strike."                             │
│    👤 Passive: Invisibility on hit                              │
│    👤 Active: Vanish dash (right-click)                         │
│                                                                 │
│  Config: weapons.shadow-dagger.invisibility-duration-seconds   │
│  Identifier: HOPLITE_SHADOW_DAGGER                             │
│                                                                 │
│  /give command:                                                 │
│  /give @p golden_sword{CustomModelData:2004,                   │
│    display:{Name:'{"text":"Shadow Dagger",                     │
│    "color":"dark_purple","bold":true}'}}                       │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  ICE BLADE                                                      │
│  Class: IceBlade.java  |  Key: ice-blade                      │
│  Base Material: STONE_SWORD  |  CustomModelData: 2005         │
│  Texture: textures/item/custom/ice_blade.png                   │
│                                                                 │
│  Enchantments: Sharpness III, Unbreaking III                   │
│  Passive: Slowness III + Blindness on hit                      │
│  Active:  Right-click → freezes all nearby foes               │
│                                                                 │
│  Lore:                                                          │
│    "Carved from a glacier that never sees the sun."            │
│    ❄ Passive: Slow + Blindness on hit                          │
│    ❄ Active: Freeze nearby foes (right-click)                  │
│                                                                 │
│  Config: weapons.ice-blade.slow-duration-seconds (default 4)   │
│  Identifier: HOPLITE_ICE_BLADE                                 │
│                                                                 │
│  /give command:                                                 │
│  /give @p stone_sword{CustomModelData:2005,                    │
│    display:{Name:'{"text":"Ice Blade","color":"dark_aqua",     │
│    "bold":true}'}}                                             │
└─────────────────────────────────────────────────────────────────┘

=====================================================
  RESOURCE PACK FILE STRUCTURE
=====================================================

  pack.mcmeta       <- Pack format 18, description
  pack.png          <- 64x64 dark shield icon
  README.txt        <- This file

  assets/minecraft/
    models/item/
      diamond_sword.json    <- CustomModelData 2001 → zeus_sword
      diamond_axe.json      <- CustomModelData 2002 → inferno_axe
      iron_axe.json         <- CustomModelData 2003 → thunder_hammer
      golden_sword.json     <- CustomModelData 2004 → shadow_dagger
      stone_sword.json      <- CustomModelData 2005 → ice_blade
      custom/
        zeus_sword.json
        inferno_axe.json
        thunder_hammer.json
        shadow_dagger.json
        ice_blade.json
    textures/item/custom/
        zeus_sword.png      <- 16x16 electric blue, lightning runes
        inferno_axe.png     <- 16x16 lava red, magma cracks
        thunder_hammer.png  <- 16x16 gold+steel, electric core
        shadow_dagger.png   <- 16x16 void purple, smoke
        ice_blade.png       <- 16x16 ice crystal, frost shards

  plugin-source/
    LegendaryWeapon.java    <- Abstract base class
    WeaponRegistry.java     <- Registers all 5 weapons
    ZeusSword.java
    InfernoAxe.java
    ThunderHammer.java
    ShadowDagger.java
    IceBlade.java

=====================================================
  HOW CustomModelData WORKS
=====================================================

The resource pack overrides specific vanilla item models to
display custom textures when CustomModelData matches:

  diamond_sword.json contains:
  "overrides": [
    { "predicate": {"custom_model_data": 2001},
      "model": "item/custom/zeus_sword" }
  ]

The plugin sets this via ItemMeta.setCustomModelData(2001).
Without the resource pack the item shows as a normal diamond
sword; with the pack it shows the Zeus Sword texture.

=====================================================
  COMPATIBILITY
=====================================================
  Minecraft Java Edition 1.20.x  (Pack Format 18)
  Also compatible: 1.19.x (format 12+), 1.18.x (format 8+)
  Texture resolution: 16x16 transparent PNG
  Engine: PaperMC / Spigot 1.20.x

  For older versions, change pack_format in pack.mcmeta:
    1.19.x → 12   |   1.18.x → 8   |   1.17.x → 7

=====================================================
  Hoplite Realm — Hunger Games / Hoplite PvP Server
=====================================================
